package de.unistuttgart.iste.sqa.pse.sheet08.homework.olympics;

public final class FeedNeverStrategy implements FeedingStrategy{

	@Override
	public boolean isFeedingRequired() {
		return false;
	}

}
