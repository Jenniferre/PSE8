package de.unistuttgart.iste.sqa.pse.sheet08.homework.olympics;

public final class RunSteadilyRacePlan implements RacePlan {
	@Override
	public void nextStep(final RunnerHamster hamster) {
		// put your code for task (c) here
		try {
			hamster.runSteadily();
		} catch (IllegalStateException noEnergyLeft) {
			hamster.runSlowly();
		}
	}
}
