package de.unistuttgart.iste.sqa.pse.sheet08.homework.olympics;

public final class OlympicsHamsterGameApp {
    public static void main(String[] args) {
        final OlympicsHamsterGame game = new OlympicsHamsterGame();
        game.doRun();
    }
}
