package de.unistuttgart.iste.sqa.pse.sheet08.homework.olympics;

public final class SprinterRacePlan implements RacePlan {

	@Override
	public void nextStep(final RunnerHamster hamster) {
		// put your code for task (c) here
		try {
			hamster.runHard();
		} catch (IllegalStateException noEnergyLeft) {
			hamster.runSlowly();
		}
	}

}
